'use strict';

function factorsOf(n) {
    if(Number.isNaN(Number(n))) {
        throw new RangeError('Argument Error: Value must be an integer');
    }
    if(n < 0) {
        throw new RangeError('Argument Error: Number must be positive');
    }
    if(!Number.isInteger(n)) {
        throw new RangeError('Argument Error: Number must be an integer');
    }
    const factors = [];
    for (let i=1 , max = Math.sqrt(n); i <= max ; i++) {
        if (n%i === 0){
        factors.push(i,n/i);
        }
    }
    return factors.sort((a,b) => a - b);
}
test('factors of 12', () => {
    expect(factorsOf(12)).toEqual([1,2,3,4,6,12]);
});

/*********************************************************
 * Let’s write another function called isPrime() that will 
 * return true if a number is prime andfalseif it isn’t.
 *********************************************************/
function isPrime(n) {
    try {
        return factorsOf(n).length === 2;
    } catch(error) {
        return false;
    }
}
test('2 is prime', () => {
    expect(isPrime(2)).toBe(true);
});
test('10 is not prime', () => {
    expect(isPrime(10)).not.toBe(true);
});

// Throw an exception to indicate that an
// incorrect argument has been used.
it('should throw an exception for non-numerical data', () => {
    expect(() => factorsOf('twelve')).toThrow();
    // Code in book missing Arrow Notation:
    //  expect(factorsOf('twelve')).toThrow();
});

it('should throw an exception for negative numbers', () => {
    expect(() => factorsOf(-2)).toThrow();
});

it('should throw an exception for non-integer numbers', () => {
    expect(() => factorsOf(3.14159)).toThrow();
});

// While we’re at it, we can add some extra
// tests so the isPrime() function also deals
// with any incorrect arguments.
test('non-numerical data returns not prime', () => {
    expect(isPrime('two')).toBe(false);
});

test('non-integer numbers return not prime', () => {
    expect(isPrime(1.2)).toBe(false);
});

test('negative numbers return not prime', () => {
    expect(isPrime(-1)).toBe(false);
});